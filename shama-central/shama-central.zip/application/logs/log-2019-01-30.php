<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-30 18:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:12:12 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:12:12 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\1_widget_student_progress.php 263
ERROR - 2019-01-30 18:12:12 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\1_widget_student_progress.php 264
ERROR - 2019-01-30 18:12:12 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\2_widget_schedules.php 33
ERROR - 2019-01-30 18:12:12 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\2_widget_schedules.php 34
ERROR - 2019-01-30 18:12:13 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\3_widget_calendar.php 296
ERROR - 2019-01-30 18:12:13 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\3_widget_calendar.php 297
ERROR - 2019-01-30 18:13:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:13:44 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:13:44 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\2_widget_schedules.php 33
ERROR - 2019-01-30 18:13:44 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\2_widget_schedules.php 34
ERROR - 2019-01-30 18:13:44 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\3_widget_calendar.php 296
ERROR - 2019-01-30 18:13:44 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\3_widget_calendar.php 297
ERROR - 2019-01-30 18:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:14:43 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:14:43 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\2_widget_schedules.php 33
ERROR - 2019-01-30 18:14:43 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\2_widget_schedules.php 34
ERROR - 2019-01-30 18:14:43 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\ci\widgets\3_widget_calendar.php 296
ERROR - 2019-01-30 18:14:43 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\ci\widgets\3_widget_calendar.php 297
ERROR - 2019-01-30 18:15:10 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:15:10 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:16:11 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:16:57 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:20:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:20:25 --> Severity: Notice --> Undefined variable: topbarsetting F:\_Shama\shama-repo\application\views\__layout\topbar.php 102
ERROR - 2019-01-30 18:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:31:30 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-01-30 18:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
