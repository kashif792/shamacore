<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-07 07:00:58 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 280
ERROR - 2018-12-07 07:01:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 280
ERROR - 2018-12-07 07:02:27 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 282
ERROR - 2018-12-07 07:25:58 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) F:\_Shama\shama-repo\application\controllers\Lmsapi.php 867
ERROR - 2018-12-07 07:26:10 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) F:\_Shama\shama-repo\application\controllers\Lmsapi.php 867
ERROR - 2018-12-07 17:46:42 --> Severity: error --> Exception: Call to undefined method LMSApi::base_url() F:\_Shama\shama-repo\application\controllers\Lmsapi.php 957
ERROR - 2018-12-07 13:57:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '%7B%7Bteacher.profilelink%7D%7D' at line 1 - Invalid query: Select * from invantageuser where id= %7B%7Bteacher.profilelink%7D%7D
ERROR - 2018-12-07 13:59:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '%7B%7Bteacher.profilelink%7D%7D' at line 1 - Invalid query: Select * from invantageuser where id= %7B%7Bteacher.profilelink%7D%7D
ERROR - 2018-12-07 14:11:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '%7B%7Bteacher.profilelink%7D%7D' at line 1 - Invalid query: Select * from invantageuser where id= %7B%7Bteacher.profilelink%7D%7D
