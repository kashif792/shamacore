<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-14 11:55:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'shama_dev' C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-11-14 11:55:43 --> Unable to connect to the database
ERROR - 2019-11-14 12:43:24 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-11-14 12:43:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
