<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-27 07:58:24 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:51 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:51 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:51 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:55 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:55 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:55 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:57 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:58 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:58 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:58:58 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:59:10 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:59:10 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:59:20 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:59:20 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 07:59:20 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:20 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:23 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:25 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:25 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:27 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:31 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:33 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:57 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:00:58 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:03:45 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:03:48 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:04:52 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:04:54 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:04:54 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:05:37 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:05:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:05:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:06:37 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:06:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:06:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:07:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:07:08 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:07:08 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:08:40 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:08:42 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:08:42 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:12:26 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:12:27 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:12:28 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:12:44 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:13:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:13:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:13:34 --> Severity: Notice --> Trying to get property 'inputclassid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 849
ERROR - 2019-11-27 08:13:34 --> Severity: Notice --> Trying to get property 'inputsemesterid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 850
ERROR - 2019-11-27 08:13:34 --> Severity: Notice --> Trying to get property 'inputsessionid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 851
ERROR - 2019-11-27 08:13:34 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:14:13 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:14:15 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:05 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:07 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:19 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:25 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:31 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 08:15:52 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 09:16:56 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 09:17:15 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 09:17:23 --> Severity: Notice --> Trying to get property 'inputclassid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 849
ERROR - 2019-11-27 09:17:23 --> Severity: Notice --> Trying to get property 'inputsemesterid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 850
ERROR - 2019-11-27 09:17:23 --> Severity: Notice --> Trying to get property 'inputsessionid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 851
ERROR - 2019-11-27 09:17:23 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 09:18:21 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 09:18:24 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 09:18:29 --> Severity: Notice --> Trying to get property 'inputclassid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 849
ERROR - 2019-11-27 09:18:29 --> Severity: Notice --> Trying to get property 'inputsemesterid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 850
ERROR - 2019-11-27 09:18:29 --> Severity: Notice --> Trying to get property 'inputsessionid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 851
ERROR - 2019-11-27 09:18:29 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 10:09:19 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 14:31:44 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-27 14:56:01 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
