<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-09 07:32:58 --> Severity: Error --> Class CI_Session_database_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::0, SessionHandlerInterface::0) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-09 07:32:58 --> Severity: Error --> Class CI_Session_database_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::0, SessionHandlerInterface::0) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-04-09 10:33:26 --> Severity: Notice --> Undefined variable: is_nic_found F:\_Shama\shama-repo\application\controllers\Ips.php 1272
ERROR - 2019-04-09 10:33:26 --> Severity: Notice --> Undefined variable: is_user_editing_nic F:\_Shama\shama-repo\application\controllers\Ips.php 1277
ERROR - 2019-04-09 10:33:26 --> Severity: Notice --> Undefined property: Ips::$operation F:\_Shama\shama-repo\application\controllers\Ips.php 1287
ERROR - 2019-04-09 10:33:26 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\controllers\Ips.php 1287
ERROR - 2019-04-09 10:34:30 --> Severity: Notice --> Undefined property: Ips::$operation F:\_Shama\shama-repo\application\controllers\Ips.php 1312
ERROR - 2019-04-09 10:34:30 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\controllers\Ips.php 1312
ERROR - 2019-04-09 10:55:59 --> Severity: Notice --> Undefined property: Ips::$operation F:\_Shama\shama-repo\application\controllers\Ips.php 1312
ERROR - 2019-04-09 10:55:59 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\controllers\Ips.php 1312
ERROR - 2019-04-09 11:08:44 --> Severity: Notice --> Undefined property: Ips::$operation F:\_Shama\shama-repo\application\controllers\Ips.php 1312
ERROR - 2019-04-09 11:08:44 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\controllers\Ips.php 1312
