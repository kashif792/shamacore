<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-04 17:26:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: Select assi.*,s.section_name, s.id  from assignsections assi INNER JOIN sections s ON s.id = assi.sectionid where assi.status = 'a' AND assi.classid  =
