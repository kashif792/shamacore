<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-28 06:46:07 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-28 06:49:41 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
