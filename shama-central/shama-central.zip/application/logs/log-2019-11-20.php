<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-20 08:09:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or '{' C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1437
ERROR - 2019-11-20 08:09:03 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or '{' C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1437
ERROR - 2019-11-20 08:13:28 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\edit_datesheet.php 83
ERROR - 2019-11-20 08:13:28 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\edit_datesheet.php 84
ERROR - 2019-11-20 08:13:28 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\edit_datesheet.php 646
ERROR - 2019-11-20 08:13:28 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\edit_datesheet.php 647
ERROR - 2019-11-20 15:19:57 --> Severity: Notice --> Undefined variable: roles_right C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:19:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:20:39 --> Severity: Notice --> Undefined variable: roles_right C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:20:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:22:23 --> Severity: Notice --> Undefined variable: roles_right C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:22:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:33:06 --> Severity: Notice --> Undefined variable: roles_right C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:33:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:34:50 --> Severity: Notice --> Undefined variable: roles_right C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
ERROR - 2019-11-20 15:34:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 153
