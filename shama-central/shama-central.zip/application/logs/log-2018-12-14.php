<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-14 13:04:50 --> Severity: error --> Exception: Call to undefined function get() F:\_Shama\shama-repo\application\controllers\Lmsapi.php 2689
ERROR - 2018-12-14 13:05:50 --> Severity: error --> Exception: Call to undefined function get() F:\_Shama\shama-repo\application\controllers\Lmsapi.php 2723
