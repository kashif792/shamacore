<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-15 04:41:21 --> Query error: Table 'shamacentral.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'eknjt48bob6q48lu929v6tpjnsp1afal'
AND `ip_address` = '::1'
ERROR - 2019-11-15 04:41:21 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-11-15 04:41:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: c:/wamp64/tmp) Unknown 0
ERROR - 2019-11-15 04:41:38 --> Query error: Table 'shamacentral.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'eknjt48bob6q48lu929v6tpjnsp1afal'
AND `ip_address` = '::1'
ERROR - 2019-11-15 04:41:38 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-11-15 04:41:38 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: c:/wamp64/tmp) Unknown 0
ERROR - 2019-11-15 04:41:39 --> Query error: Table 'shamacentral.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'eknjt48bob6q48lu929v6tpjnsp1afal'
AND `ip_address` = '::1'
ERROR - 2019-11-15 04:41:39 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-11-15 04:41:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: c:/wamp64/tmp) Unknown 0
ERROR - 2019-11-15 04:41:39 --> Query error: Table 'shamacentral.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'eknjt48bob6q48lu929v6tpjnsp1afal'
AND `ip_address` = '::1'
ERROR - 2019-11-15 04:41:39 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-11-15 04:41:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: c:/wamp64/tmp) Unknown 0
ERROR - 2019-11-15 04:41:40 --> Query error: Table 'shamacentral.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'eknjt48bob6q48lu929v6tpjnsp1afal'
AND `ip_address` = '::1'
ERROR - 2019-11-15 04:41:40 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-11-15 04:41:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: c:/wamp64/tmp) Unknown 0
ERROR - 2019-11-15 04:41:44 --> Query error: Table 'shamacentral.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'eknjt48bob6q48lu929v6tpjnsp1afal'
AND `ip_address` = '::1'
ERROR - 2019-11-15 04:41:44 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-11-15 04:41:44 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: c:/wamp64/tmp) Unknown 0
ERROR - 2019-11-15 11:35:41 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 729
ERROR - 2019-11-15 11:37:01 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 729
ERROR - 2019-11-15 11:40:23 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 713
ERROR - 2019-11-15 11:41:44 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 713
ERROR - 2019-11-15 11:42:05 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 713
ERROR - 2019-11-15 11:45:12 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 713
ERROR - 2019-11-15 11:46:00 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 177
ERROR - 2019-11-15 11:46:00 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 713
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 89
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 91
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 92
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 95
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 97
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 98
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 101
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 103
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 104
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 107
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 109
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 110
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 113
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 115
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 116
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 119
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 121
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 122
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 125
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 127
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 128
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:21:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:21:00 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:21:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 89
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 91
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 92
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 95
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 97
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 98
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 101
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 103
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 104
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 107
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 109
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 110
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 113
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 115
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 116
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 119
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 121
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 122
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 125
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 127
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 128
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:22:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:22:40 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:22:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 89
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 91
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 92
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 95
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 97
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 98
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 101
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 103
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 104
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 107
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 109
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 110
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 113
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 115
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 116
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 119
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 121
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 122
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 125
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 127
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 128
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:22:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:22:57 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:22:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 89
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 91
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 92
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 95
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 97
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 98
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 101
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 103
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 104
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 107
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 109
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 110
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 113
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 115
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 116
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 119
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 121
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 122
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 125
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 127
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 128
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:23:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:23:03 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:23:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 89
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 91
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 92
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 95
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 97
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 98
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 101
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 103
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 104
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 107
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 109
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 110
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 113
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 115
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 116
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 119
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 121
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 122
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 125
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 127
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 128
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 404
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 405
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 406
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 407
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 408
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 409
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 410
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 411
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 412
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 413
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 414
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 415
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 416
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 417
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:23:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 917
ERROR - 2019-11-15 12:23:15 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
ERROR - 2019-11-15 12:23:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\exam_timetble_list.php 933
