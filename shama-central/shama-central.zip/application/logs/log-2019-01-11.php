<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-11 11:30:12 --> Query error: Unknown column 'sectionid' in 'field list' - Invalid query: UPDATE `defaultlessonplan` SET `day` = '60', `concept` = 'Read sentences', `topic` = 'Concept of this/that', `lesson` = 'Student will be able to use this and that', `type` = 'Video', `content` = '', `thumb` = '', `classid` = '1', `sectionid` = NULL, `subjectid` = '1', `semesterid` = '2', `last_update` = '2019-01-11 11:30:12'
WHERE `id` = '362'
ERROR - 2019-01-11 11:30:24 --> Query error: Unknown column 'sectionid' in 'field list' - Invalid query: UPDATE `defaultlessonplan` SET `day` = '60', `concept` = 'Read sentences', `topic` = 'Concept of this/that', `lesson` = 'Student will be able to use this and that', `type` = 'Video', `content` = '', `thumb` = '', `classid` = '1', `sectionid` = NULL, `subjectid` = '1', `semesterid` = '2', `last_update` = '2019-01-11 11:30:24'
WHERE `id` = '362'
ERROR - 2019-01-11 11:38:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM semester_lesson_plan WHERE uniquecode= '5bfcfde80a4ff' AND sectionid= 
