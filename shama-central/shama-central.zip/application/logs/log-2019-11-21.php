<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-21 04:50:15 --> Severity: Notice --> Undefined variable: roles_right C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 152
ERROR - 2019-11-21 04:50:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 152
ERROR - 2019-11-21 04:52:47 --> Severity: Notice --> Undefined variable: classid C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 239
ERROR - 2019-11-21 04:52:47 --> Severity: Notice --> Undefined variable: sectionslist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 417
ERROR - 2019-11-21 04:54:13 --> Severity: Notice --> Undefined variable: classid C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 239
ERROR - 2019-11-21 04:54:13 --> Severity: Notice --> Undefined variable: sectionslist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 417
ERROR - 2019-11-21 04:58:59 --> Severity: Notice --> Undefined variable: classid C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 251
ERROR - 2019-11-21 04:58:59 --> Severity: Notice --> Undefined variable: sectionslist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 429
ERROR - 2019-11-21 04:59:11 --> Severity: Notice --> Undefined variable: classid C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 248
ERROR - 2019-11-21 04:59:11 --> Severity: Notice --> Undefined variable: sectionslist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 426
ERROR - 2019-11-21 04:59:54 --> Severity: Notice --> Undefined variable: sectionslist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 426
ERROR - 2019-11-21 05:00:41 --> Severity: Notice --> Undefined variable: sectionslist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 426
ERROR - 2019-11-21 05:06:27 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:06:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:09:51 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:09:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:12:42 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:12:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:21:24 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:21:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\teacher\addquizz.php 256
ERROR - 2019-11-21 05:31:26 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:31:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:31:26 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:43:23 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:43:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:43:23 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:43:42 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:43:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:43:42 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:44:02 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:44:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:44:03 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:48:45 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:48:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:48:45 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:48:53 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:48:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:48:54 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:49:04 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:49:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:49:04 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:49:41 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:49:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:49:41 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:54:17 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:54:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:54:17 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:56:53 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:56:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:56:53 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:58:24 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:58:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:58:24 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 05:59:51 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:59:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 05:59:52 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:00:48 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:00:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:00:48 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:01:53 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:01:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:01:53 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:03:27 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:03:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:03:27 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:03:38 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:03:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:03:38 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:03:42 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:03:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:03:42 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:05:25 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:05:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:05:26 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:05:50 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:05:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:08:03 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:08:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:10:23 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:10:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:10:54 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:10:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-21 06:13:00 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:27:02 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:27:50 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:28:18 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:29:21 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:38:18 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:43:52 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:45:08 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:45:12 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:45:27 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:45:30 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:46:42 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:46:43 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:56:03 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 06:56:04 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:02:12 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:02:14 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:02:18 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:02:43 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:02:45 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:08:27 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:08:27 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:09:55 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:09:56 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:09:57 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:09:57 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:08 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:08 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:17 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:17 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:18 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:27:18 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:29:28 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:29:28 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:29:29 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:29:29 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:29:58 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 07:29:58 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetCurrentSemesterData() C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 351
ERROR - 2019-11-21 14:27:51 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 2745
ERROR - 2019-11-21 14:27:51 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 2749
ERROR - 2019-11-21 14:27:51 --> Severity: error --> Exception: Call to undefined method stdClass::Create() C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 2750
