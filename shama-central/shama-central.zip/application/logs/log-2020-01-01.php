<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-01 15:53:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions.
 C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-01-01 15:53:24 --> Unable to connect to the database
