<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-19 09:50:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'zinweb5_zilon_shama'@'localhost' (using password: YES) F:\_Shama\shama-repo\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-04-19 09:50:42 --> Unable to connect to the database
ERROR - 2019-04-19 10:15:19 --> Severity: error --> Exception: syntax error, unexpected 'e' (T_STRING), expecting variable (T_VARIABLE) F:\_Shama\shama-repo\application\controllers\TaskController.php 88
