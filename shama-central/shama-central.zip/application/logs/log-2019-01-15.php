<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-15 08:07:03 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\core\MY_Controller.php 316
ERROR - 2019-01-15 08:09:33 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\core\MY_Controller.php 316
ERROR - 2019-01-15 08:45:30 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() F:\_Shama\shama-repo\application\controllers\Principal_Extension_controller.php 622
ERROR - 2019-01-15 10:52:47 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\core\MY_Controller.php 316
