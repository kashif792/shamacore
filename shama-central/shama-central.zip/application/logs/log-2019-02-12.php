<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-12 10:30:53 --> Severity: Notice --> Undefined variable: classlist F:\_Shama\shama-repo\application\views\principal\Principal_Extension_View\Tablet_List.php 100
