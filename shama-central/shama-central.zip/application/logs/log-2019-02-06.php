<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-06 08:26:56 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\show_student_list.php 1386
ERROR - 2019-02-06 08:26:56 --> Severity: Notice --> Undefined variable: role_id F:\_Shama\shama-repo\application\views\principal\show_student_list.php 1387
ERROR - 2019-02-06 08:26:56 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\show_student_list.php 1388
