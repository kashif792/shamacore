<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-24 06:07:39 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-12-24 06:07:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-12-24 06:44:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions.
 C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-12-24 06:44:44 --> Unable to connect to the database
ERROR - 2019-12-24 10:31:43 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-12-24 10:31:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
