<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-22 04:59:13 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 547
ERROR - 2019-11-22 05:06:40 --> Severity: Notice --> Undefined variable: path_url C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 6
ERROR - 2019-11-22 05:07:41 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\teacher\show_quizz_list.php 431
ERROR - 2019-11-22 05:26:46 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:26:46 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:26:46 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:26:46 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:27:35 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:27:35 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:27:35 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:27:35 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:29:08 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:29:08 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:29:08 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:29:08 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:30:38 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:30:38 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:30:38 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:30:38 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:33:53 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:33:53 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:33:53 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:33:53 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:03 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:03 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:03 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:03 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:29 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:29 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:29 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:29 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:42 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:42 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:42 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:35:42 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:36:29 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1288
ERROR - 2019-11-22 05:37:34 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:37:34 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:37:34 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:37:34 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:38:53 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:38:53 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:38:53 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:38:53 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:39:13 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:39:13 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:39:13 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:39:13 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:40:55 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:40:55 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:40:55 --> Severity: Notice --> Undefined property: Principal_controller::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 05:40:55 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1200
ERROR - 2019-11-22 08:11:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions.
 C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-11-22 08:11:42 --> Unable to connect to the database
ERROR - 2019-11-22 12:53:41 --> Severity: Warning --> Use of undefined constant QUIZ_TOTAL_MARKS - assumed 'QUIZ_TOTAL_MARKS' (this will throw an Error in a future version of PHP) C:\wamp64\www\shamacore\shama-central\application\views\teacher\widgets\1_widget_student_progress.php 640
ERROR - 2019-11-22 12:53:41 --> Severity: Warning --> Use of undefined constant MID_TOTAL_MARKS - assumed 'MID_TOTAL_MARKS' (this will throw an Error in a future version of PHP) C:\wamp64\www\shamacore\shama-central\application\views\teacher\widgets\1_widget_student_progress.php 752
ERROR - 2019-11-22 12:53:41 --> Severity: Warning --> Use of undefined constant FINAL_TOTAL_MARKS - assumed 'FINAL_TOTAL_MARKS' (this will throw an Error in a future version of PHP) C:\wamp64\www\shamacore\shama-central\application\views\teacher\widgets\1_widget_student_progress.php 756
