<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-08 05:43:57 --> Severity: Error --> Class CI_Session_database_driver contains 3 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::t, SessionHandlerInterface::mysqlnd, SessionHandlerInterface::h@) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-08 05:43:57 --> Severity: Error --> Class CI_Session_database_driver contains 3 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::t, SessionHandlerInterface::mysqlnd, SessionHandlerInterface::h@) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-08 05:43:57 --> Severity: Error --> Class CI_Session_database_driver contains 3 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::t, SessionHandlerInterface::mysqlnd, SessionHandlerInterface::h@) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-08 05:43:57 --> Severity: Error --> Class CI_Session_database_driver contains 3 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::t, SessionHandlerInterface::mysqlnd, SessionHandlerInterface::h@) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:22:00 --> Severity: Notice --> Undefined variable: classlist F:\_Shama\shama-repo\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-02-08 06:25:31 --> Severity: Notice --> Undefined variable: classlist F:\_Shama\shama-repo\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-02-08 06:25:41 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:25:41 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:25:41 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:25:41 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:29:32 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:29:59 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 06:30:55 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::read) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 08:11:49 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::open) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 08:11:49 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::open) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 08:11:49 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::open) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 08:11:49 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::open) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 08:14:43 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::open) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-08 08:24:38 --> Severity: Notice --> Undefined variable: classlist F:\_Shama\shama-repo\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-02-08 11:59:38 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 11:59:38 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:02:16 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:02:16 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:04:02 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:04:02 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:31:57 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:31:57 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:32:56 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:32:56 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:33:44 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:33:44 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:43:00 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:43:00 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:44:15 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:49:33 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:49:33 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:53:14 --> Severity: Notice --> Undefined property: stdClass::$profile F:\_Shama\shama-repo\application\controllers\Reports.php 394
ERROR - 2019-02-08 12:53:14 --> Severity: Warning --> file_get_contents(): Filename cannot be empty F:\_Shama\shama-repo\application\core\MY_Controller.php 80
ERROR - 2019-02-08 12:58:20 --> Severity: Warning --> file_get_contents(http://zilonlahore/shama-core/upload/upload/profile/15447019034de05a8c8266197747e6e8a14a1e796a.jpg): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 F:\_Shama\shama-repo\application\core\MY_Controller.php 80
