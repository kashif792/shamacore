<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-24 07:28:10 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 1143
ERROR - 2019-05-24 07:28:31 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' F:\_Shama\shama-repo\application\controllers\Principal_controller.php 1143
