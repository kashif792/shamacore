<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-08 15:18:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) E:\www\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-01-08 15:18:41 --> Unable to connect to the database
