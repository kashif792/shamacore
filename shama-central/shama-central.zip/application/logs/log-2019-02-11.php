<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: teacher_firstname F:\_Shama\shama-repo\application\views\settings\profile.php 96
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: teacher_lastname F:\_Shama\shama-repo\application\views\settings\profile.php 104
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: email_get F:\_Shama\shama-repo\application\views\settings\profile.php 114
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: gender F:\_Shama\shama-repo\application\views\settings\profile.php 150
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: gender F:\_Shama\shama-repo\application\views\settings\profile.php 151
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: gender F:\_Shama\shama-repo\application\views\settings\profile.php 152
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: primary_address F:\_Shama\shama-repo\application\views\settings\profile.php 175
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: secondary_address F:\_Shama\shama-repo\application\views\settings\profile.php 183
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 193
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 194
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 195
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 196
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 197
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 198
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 199
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 200
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: province F:\_Shama\shama-repo\application\views\settings\profile.php 201
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: city F:\_Shama\shama-repo\application\views\settings\profile.php 210
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: teacher_zipcode F:\_Shama\shama-repo\application\views\settings\profile.php 221
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: profile_link F:\_Shama\shama-repo\application\views\settings\profile.php 232
ERROR - 2019-02-11 13:11:16 --> Severity: Notice --> Undefined variable: profile_link F:\_Shama\shama-repo\application\views\settings\profile.php 306
ERROR - 2019-02-11 12:35:48 --> Severity: Notice --> Undefined variable: SHAMA_CORE_API_PATH F:\_Shama\shama-repo\application\views\principal\show_prinicpal_list.php 438
