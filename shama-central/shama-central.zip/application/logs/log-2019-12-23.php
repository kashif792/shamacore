<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-23 12:36:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-12-23 12:36:35 --> Unable to connect to the database
