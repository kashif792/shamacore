<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-01 15:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 16:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 16:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 16:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 16:35:15 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 16:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 16:37:43 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 17:22:39 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 17:23:44 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 17:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 17:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 17:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-01 17:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
