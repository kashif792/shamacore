<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-26 06:11:20 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\show_datesheet_list.php 394
ERROR - 2019-12-26 06:12:24 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\show_announcement_list.php 688
ERROR - 2019-12-26 06:16:06 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\show_announcement_list.php 420
ERROR - 2019-12-26 06:20:12 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\show_announcement_list.php 493
ERROR - 2019-12-26 06:20:32 --> Severity: Notice --> Undefined variable: logo C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\show_announcement_list.php 493
ERROR - 2019-12-26 10:46:53 --> Severity: Notice --> Undefined variable: annoucement C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\view_announcement.php 97
ERROR - 2019-12-26 10:46:53 --> Severity: Notice --> Trying to get property 'title' of non-object C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\view_announcement.php 97
ERROR - 2019-12-26 10:56:14 --> Severity: Notice --> Undefined variable: annoucement C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\view_announcement.php 97
ERROR - 2019-12-26 10:56:14 --> Severity: Notice --> Trying to get property 'title' of non-object C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\view_announcement.php 97
ERROR - 2019-12-26 12:47:41 --> Severity: error --> Exception: Call to undefined function validPhoneNumber() C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\show_announcement_list.php 68
ERROR - 2019-12-26 12:48:41 --> Severity: error --> Exception: Call to undefined function validPhoneNumber() C:\wamp64\www\shamacore\shama-central\application\views\principal\announcement\show_announcement_list.php 68
