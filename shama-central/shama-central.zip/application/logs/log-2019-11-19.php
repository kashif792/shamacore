<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-19 11:48:57 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1496
ERROR - 2019-11-19 11:48:59 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\wamp64\www\shamacore\shama-central\application\controllers\Principal_controller.php 1496
ERROR - 2019-11-19 11:50:27 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 997
ERROR - 2019-11-19 11:50:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 997
ERROR - 2019-11-19 11:50:27 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 1013
ERROR - 2019-11-19 11:50:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 1013
ERROR - 2019-11-19 11:53:13 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 980
ERROR - 2019-11-19 11:53:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 980
ERROR - 2019-11-19 11:53:13 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 996
ERROR - 2019-11-19 11:53:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 996
ERROR - 2019-11-19 11:56:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 980
ERROR - 2019-11-19 11:56:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 980
ERROR - 2019-11-19 11:56:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 996
ERROR - 2019-11-19 11:56:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\datesheet\add_datesheet.php 996
