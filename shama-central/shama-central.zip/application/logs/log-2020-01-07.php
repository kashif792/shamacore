<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-07 07:43:00 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2020-01-07 07:43:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
