<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-03 14:16:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 219
ERROR - 2018-12-03 14:19:58 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 219
