<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-03 18:04:33 --> Severity: error --> Exception: Call to undefined method LMSApi::GetStudentName() F:\_Shama\shama-repo\application\controllers\Lmsapi.php 2779
ERROR - 2019-01-03 18:05:08 --> Severity: error --> Exception: Call to undefined method LMSApi::GetStudentName() F:\_Shama\shama-repo\application\controllers\Lmsapi.php 2777
