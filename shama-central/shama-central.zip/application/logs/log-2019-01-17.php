<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-17 16:36:22 --> Severity: error --> Exception: Call to undefined method stdClass::Create() F:\_Shama\shama-repo\application\controllers\Ips.php 630
