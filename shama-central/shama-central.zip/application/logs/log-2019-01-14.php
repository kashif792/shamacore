<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-14 16:08:23 --> Severity: error --> Exception: Call to undefined method stdClass::GetRowsByQyery() F:\_Shama\shama-repo\application\controllers\Ips.php 1604
ERROR - 2019-01-14 16:08:23 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() F:\_Shama\shama-repo\application\controllers\Ips.php 1833
ERROR - 2019-01-14 16:08:23 --> Severity: error --> Exception: Call to undefined method stdClass::GetRows() F:\_Shama\shama-repo\application\controllers\Ips.php 1710
ERROR - 2019-01-14 16:08:23 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() F:\_Shama\shama-repo\application\controllers\Ips.php 1857
ERROR - 2019-01-14 16:08:23 --> Severity: error --> Exception: Call to undefined method stdClass::GetRowsByQyery() F:\_Shama\shama-repo\application\controllers\Ips.php 1604
ERROR - 2019-01-14 16:15:27 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\controllers\Principal_controller.php 1443
ERROR - 2019-01-14 16:16:22 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null F:\_Shama\shama-repo\application\controllers\Principal_controller.php 1443
ERROR - 2019-01-14 16:36:39 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() F:\_Shama\shama-repo\application\core\MY_Controller.php 458
ERROR - 2019-01-14 16:38:43 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() F:\_Shama\shama-repo\application\core\MY_Controller.php 458
ERROR - 2019-01-14 16:40:49 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() F:\_Shama\shama-repo\application\core\MY_Controller.php 458
ERROR - 2019-01-14 16:42:24 --> Severity: error --> Exception: Call to undefined method stdClass::GetRows() F:\_Shama\shama-repo\application\controllers\Teacher.php 1930
ERROR - 2019-01-14 16:45:43 --> Severity: error --> Exception: syntax error, unexpected '{', expecting function (T_FUNCTION) F:\_Shama\shama-repo\application\controllers\Teacher.php 74
