<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-06 11:10:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\controllers\Lmsapi.php 797
ERROR - 2018-12-06 11:12:06 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\controllers\Lmsapi.php 797
ERROR - 2018-12-06 11:12:29 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\controllers\Lmsapi.php 797
ERROR - 2018-12-06 11:14:24 --> Severity: error --> Exception: Cannot use object of type stdClass as array F:\_Shama\shama-repo\application\controllers\Lmsapi.php 802
ERROR - 2018-12-06 13:23:11 --> Query error: Unknown column 'session_id' in 'where clause' - Invalid query: UPDATE `schedule` SET `last_update` = '2018-12-06', `subject_id` = '1', `class_id` = '1', `section_id` = '1', `teacher_uid` = '310', `start_time` = 1544070600, `end_time` = 1544071500, `semesterid` = '1', `sessionid` = '1'
WHERE `session_id` = '1'
