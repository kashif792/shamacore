<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-07 07:50:27 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 291
ERROR - 2019-02-07 07:50:27 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 451
ERROR - 2019-02-07 07:50:27 --> Severity: Notice --> Undefined variable: role_id F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 452
ERROR - 2019-02-07 07:50:27 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 453
ERROR - 2019-02-07 07:52:42 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_teacher_list.php 291
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 91
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_teacher.php 633
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 91
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_teacher.php 633
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 91
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_teacher.php 633
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 91
ERROR - 2019-02-07 08:01:13 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_teacher.php 633
ERROR - 2019-02-07 08:01:14 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 91
ERROR - 2019-02-07 08:01:14 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_teacher.php 633
ERROR - 2019-02-07 08:01:14 --> Severity: Notice --> Undefined variable: data F:\_Shama\shama-repo\application\controllers\Principal_controller.php 91
ERROR - 2019-02-07 08:01:14 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_teacher.php 633
ERROR - 2019-02-07 08:51:58 --> Severity: Notice --> Undefined variable: roles_right F:\_Shama\shama-repo\application\views\principal\class_list.php 276
ERROR - 2019-02-07 11:15:22 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_class.php 375
ERROR - 2019-02-07 11:15:22 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_class.php 376
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: classlist F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 103
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 181
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 193
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 205
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 413
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: role_id F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 414
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 415
ERROR - 2019-02-07 11:34:37 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 416
ERROR - 2019-02-07 11:38:43 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 72
ERROR - 2019-02-07 11:38:43 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 84
ERROR - 2019-02-07 11:38:43 --> Severity: Notice --> Undefined variable: roles F:\_Shama\shama-repo\application\views\principal\show_sub_list.php 96
ERROR - 2019-02-07 11:40:58 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 120
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 121
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 122
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 120
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 121
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 122
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 120
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 121
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 122
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 120
ERROR - 2019-02-07 11:40:59 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 121
ERROR - 2019-02-07 11:41:00 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 122
ERROR - 2019-02-07 11:45:11 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 166
ERROR - 2019-02-07 11:45:11 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 167
ERROR - 2019-02-07 11:45:11 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 168
ERROR - 2019-02-07 11:45:11 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 166
ERROR - 2019-02-07 11:45:11 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 167
ERROR - 2019-02-07 11:45:11 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 168
ERROR - 2019-02-07 11:45:12 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 166
ERROR - 2019-02-07 11:45:12 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 167
ERROR - 2019-02-07 11:45:12 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 168
ERROR - 2019-02-07 11:45:12 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 166
ERROR - 2019-02-07 11:45:12 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 167
ERROR - 2019-02-07 11:45:12 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\principal\add_subject.php 168
ERROR - 2019-02-07 12:15:49 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\teacher\lesson_plan_form.php 209
ERROR - 2019-02-07 12:15:49 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\teacher\lesson_plan_form.php 210
ERROR - 2019-02-07 12:15:49 --> Severity: Notice --> Undefined variable: role_id F:\_Shama\shama-repo\application\views\teacher\lesson_plan_form.php 211
ERROR - 2019-02-07 12:15:49 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\teacher\lesson_plan_form.php 212
ERROR - 2019-02-07 17:42:39 --> Severity: Notice --> Undefined variable: session_id F:\_Shama\shama-repo\application\views\schedular\date_schedular.php 238
ERROR - 2019-02-07 17:42:39 --> Severity: Notice --> Undefined variable: school_id F:\_Shama\shama-repo\application\views\schedular\date_schedular.php 239
ERROR - 2019-02-07 17:42:39 --> Severity: Notice --> Undefined variable: user_id F:\_Shama\shama-repo\application\views\schedular\date_schedular.php 240
ERROR - 2019-02-07 17:42:39 --> Severity: Notice --> Undefined variable: role_id F:\_Shama\shama-repo\application\views\schedular\date_schedular.php 241
ERROR - 2019-02-07 17:42:39 --> Severity: Notice --> Undefined variable: is_master_teacher F:\_Shama\shama-repo\application\views\schedular\date_schedular.php 242
ERROR - 2019-02-07 13:46:09 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::destroy) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-07 13:46:09 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::destroy) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-07 13:46:09 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::destroy) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-07 13:46:09 --> Severity: Error --> Class CI_Session_database_driver contains 1 abstract method and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::destroy) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-07 17:46:22 --> Severity: Warning --> session_write_close(): Failed to write session data (user). Please verify that the current setting of session.save_path is correct (C:\xampp\tmp) Unknown 0
ERROR - 2019-02-07 13:46:23 --> Severity: Error --> Class CI_Session_database_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::���, SessionHandlerInterface::write) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
ERROR - 2019-02-07 13:46:23 --> Severity: Error --> Class CI_Session_database_driver contains 2 abstract methods and must therefore be declared abstract or implement the remaining methods (SessionHandlerInterface::���, SessionHandlerInterface::write) F:\_Shama\shama-repo\system\libraries\Session\drivers\Session_database_driver.php 49
