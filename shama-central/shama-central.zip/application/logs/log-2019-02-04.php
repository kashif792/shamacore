<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-04 15:31:25 --> Severity: Warning --> Invalid argument supplied for foreach() F:\_Shama\shama-repo\application\views\__layout\topbar.php 51
ERROR - 2019-02-04 18:29:44 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' F:\_Shama\shama-repo\application\views\__layout\leftnavigation.php 227
