<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-25 13:10:30 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-11-25 13:10:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-11-25 18:14:02 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1812
ERROR - 2019-11-25 18:14:02 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1817
ERROR - 2019-11-25 18:14:02 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1552
ERROR - 2019-11-25 18:14:02 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:14:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:17:04 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1812
ERROR - 2019-11-25 18:17:04 --> Severity: error --> Exception: Call to undefined method stdClass::GetByWhere() C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1817
ERROR - 2019-11-25 18:17:04 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1552
ERROR - 2019-11-25 18:17:04 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:17:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:17:49 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1552
ERROR - 2019-11-25 18:17:49 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:17:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:19:21 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1552
ERROR - 2019-11-25 18:19:21 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:19:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:21:08 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1552
ERROR - 2019-11-25 18:21:08 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:21:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:21:51 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1552
ERROR - 2019-11-25 18:21:51 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 18:21:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1579
ERROR - 2019-11-25 13:29:25 --> Severity: Notice --> Undefined variable: is_student_found C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-25 13:29:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\controllers\Teacher.php 332
ERROR - 2019-11-25 18:29:25 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1669
ERROR - 2019-11-25 18:29:25 --> Severity: error --> Exception: Call to undefined method stdClass::GetRows() C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1670
ERROR - 2019-11-25 18:39:16 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1669
ERROR - 2019-11-25 18:39:16 --> Severity: error --> Exception: Call to undefined method stdClass::GetRows() C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1670
ERROR - 2019-11-25 18:40:16 --> Severity: Warning --> Creating default object from empty value C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1669
ERROR - 2019-11-25 18:40:16 --> Severity: error --> Exception: Call to undefined method stdClass::GetRows() C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1670
ERROR - 2019-11-25 18:44:57 --> Severity: Notice --> Undefined property: Ips::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1645
ERROR - 2019-11-25 18:44:57 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1645
ERROR - 2019-11-25 13:44:57 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 18:46:31 --> Severity: Notice --> Undefined property: Ips::$operation C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1645
ERROR - 2019-11-25 18:46:31 --> Severity: error --> Exception: Call to a member function GetRowsByQyery() on null C:\wamp64\www\shamacore\shama-central\application\controllers\Ips.php 1645
ERROR - 2019-11-25 13:50:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 13:50:49 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 13:51:51 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 13:51:55 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 14:55:11 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 14:55:15 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:01:02 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:01:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:09:10 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:09:13 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:25:59 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:26:02 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:29:02 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:29:04 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:29:33 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:29:36 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:31:06 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:31:10 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:31:12 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:31:14 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:58:11 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:58:14 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:58:52 --> Severity: Notice --> Trying to get property 'inputclassid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 852
ERROR - 2019-11-25 15:58:52 --> Severity: Notice --> Trying to get property 'inputsemesterid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 853
ERROR - 2019-11-25 15:58:52 --> Severity: Notice --> Trying to get property 'inputsessionid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 854
ERROR - 2019-11-25 15:58:52 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:59:01 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-25 15:59:05 --> Severity: Notice --> Trying to get property 'inputclassid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 852
ERROR - 2019-11-25 15:59:05 --> Severity: Notice --> Trying to get property 'inputsemesterid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 853
ERROR - 2019-11-25 15:59:05 --> Severity: Notice --> Trying to get property 'inputsessionid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 854
ERROR - 2019-11-25 15:59:05 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
