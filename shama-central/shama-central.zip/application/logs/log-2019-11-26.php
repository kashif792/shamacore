<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-26 04:14:56 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:15:00 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:15:19 --> Severity: Notice --> Trying to get property 'inputclassid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 852
ERROR - 2019-11-26 04:15:19 --> Severity: Notice --> Trying to get property 'inputsemesterid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 853
ERROR - 2019-11-26 04:15:19 --> Severity: Notice --> Trying to get property 'inputsessionid' of non-object C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 854
ERROR - 2019-11-26 04:15:19 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:26:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions.
 C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-11-26 04:26:34 --> Unable to connect to the database
ERROR - 2019-11-26 04:26:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions.
 C:\wamp64\www\shamacore\shama-central\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-11-26 04:26:34 --> Unable to connect to the database
ERROR - 2019-11-26 04:30:02 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:30:05 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:31:20 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:31:23 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:31:25 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 04:42:09 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:01:26 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:01:30 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:12:53 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:12:56 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:22:54 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:22:57 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:24:09 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:25:29 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 870
ERROR - 2019-11-26 05:26:38 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:26:45 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:35:37 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:35:40 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:36:21 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:36:23 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:39:39 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:39:41 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:49:23 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:49:26 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:50:08 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:50:10 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:50:18 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:51:02 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:51:50 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:52:15 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 05:54:34 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 10:15:50 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 10:16:15 --> Severity: error --> Exception: Call to undefined method MY_Controller::GetSemesterBySession() C:\wamp64\www\shamacore\shama-central\application\controllers\Reports.php 867
ERROR - 2019-11-26 10:22:23 --> Severity: Notice --> Undefined variable: classlist C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
ERROR - 2019-11-26 10:22:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\wamp64\www\shamacore\shama-central\application\views\principal\Principal_Extension_View\Tablet_List.php 100
