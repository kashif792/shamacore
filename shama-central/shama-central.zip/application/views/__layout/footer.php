<!-- footer -->
	</div>
</div>
</body>
<script type="text/javascript">
	 document.getElementById('sidenav').style.height = $(window).height() + 20 + 'px';
</script>
<script src="<?php echo base_url(); ?>js/jquery-confirm.min.js"></script>



<!-- Include Date Range Picker -->
<script type="text/javascript" src="<?php echo base_url(); ?>js/daterangepicker.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>js/angular-daterangepicker.min.js"></script>


<script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script>

<script src="<?php echo base_url(); ?>js/jquery.easyResponsiveTabs.js"></script>

<script src="<?php echo base_url(); ?>js/dataTables.bootstrap.min.js"></script>

<script src="<?php echo base_url(); ?>js/dataTables.responsive.min.js"></script>

<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>

</html>
