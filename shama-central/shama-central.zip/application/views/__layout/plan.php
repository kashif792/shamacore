<!DOCTYPE html>
<html>
<head>
  <title>Page Title</title>
  <!---Lessssssssssssson plaaaaaaaaan table start-->
 <script data-jsfiddle="common" src="js/excel/demo/js/jquery.min.js"></script>

  <link data-jsfiddle="common" rel="stylesheet" media="screen" href="js/excel/dist/handsontable.css">
  <link data-jsfiddle="common" rel="stylesheet" media="screen" href="js/excel/dist/pikaday/pikaday.css">
  <script data-jsfiddle="common" src="js/excel/dist/pikaday/pikaday.js"></script>
  <script data-jsfiddle="common" src="js/excel/dist/moment/moment.js"></script>
  <script data-jsfiddle="common" src="js/excel/dist/zeroclipboard/ZeroClipboard.js"></script>
  <script data-jsfiddle="common" src="js/excel/dist/numbro/numbro.js"></script>
 
  <script data-jsfiddle="common" src="js/excel/dist/handsontable.js"></script>
  <style type="text/css">
    .navbar-nav.navbar-right:last-child {
margin-right: 0;
    position: relative;
    top: -53px;
    right: -31px;
}
  </style>
 
  
  <link data-jsfiddle="common" rel="stylesheet" media="screen" href="js/excel/demo/css/samples.css?20140331">
 
  <link rel="stylesheet" media="screen" href="js/excel/demo/js/highlight/styles/github.css">
  <link rel="stylesheet" href="js/excel/demo/css/font-awesome/css/font-awesome.min.css">
<!---Lessssssssssssson plaaaaaaaaan table end -->
</head>
<body>
</body>
</html>
