<div class="row">
    <div class="col-sm text-left title-row">
      <span>
        <a href="#!{{backbutton}}"  class="btn btn-light btn-circle-info">
          <span class="icon-reply" aria-hidden="true"></span>
        </a>
        <h3 class="d-inline">{{pagetitle}}</h3>
      </span>
    </div>
</div>
