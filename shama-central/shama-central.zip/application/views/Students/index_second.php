<!-- Container --> 
<div class="dash dashboard" ng-controller="index_ctrl">
    <div class="dshbrdicon">
        <div class="innericon container">
            <div class="row style_left">
                <div class="col-sm box1 text-right">
                    <button class="prof-close hide" type="button">&times;</button>
                      <section class="profilebox">
                        <main class="lesson-notifications">
                            <div class="row">
                                <div class="col-sm text-primary p-1">
                                    <div class="row subject-row">
                                        <div class="col-5 img-rounded" style="background: url(./images/com.png) no-repeat; min-height: 4rem;background-position: center;"></div>
                                        <div class="col-7 text-left my-auto">
                                            <h5 class="text-bold">xyx</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-sm text-primary p-1">
                                    <div class="row subject-row">
                                        <div class="col-5" style="background: url(./images/com.png) no-repeat; min-height: 4rem;background-position: center;"></div>
                                         <div class="col-7 text-left my-auto">
                                            <h5 class="text-bold">xyx</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-sm text-primary p-1">
                                    <div class="row subject-row">
                                        <div class="col-5" style="background: url(./images/com.png) no-repeat; min-height: 4rem;background-position: center;"></div>
                                         <div class="col-7 text-left my-auto">
                                            <h5 class="text-bold">xyx</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-sm text-primary p-1">
                                    <div class="row subject-row">
                                        <div class="col-5" style="background: url(./images/com.png) no-repeat; min-height: 4rem;background-position: center;"></div>
                                         <div class="col-7 text-left my-auto">
                                            <h5 class="text-bold">xyx</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-sm text-primary p-1">
                                    <div class="row subject-row">
                                        <div class="col-5" style="background: url(./images/com.png) no-repeat; min-height: 4rem;background-position: center;"></div>
                                         <div class="col-7 text-left my-auto">
                                            <h5 class="text-bold">xyx</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-sm text-primary p-1">
                                    <div class="row subject-row">
                                        <div class="col-5" style="background: url(./images/com.png) no-repeat; min-height: 4rem;background-position: center;"></div>
                                         <div class="col-7 text-left my-auto">
                                            <h5 class="text-bold">xyx</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </main>
                    </section>
                    <a href="#!subjects">
                        <div class="row">
                            <div class="col-sm text-left">
                                <img src="./images/learnd.png" class="img-fluid">
                            </div>
                            <div class="col-sm my-auto text-left hide">
                                <img src="/shamacentral/v1.1/images/video-icon.png" class="img-fluid">
                                <h3 class="card-title text-white pl-4">Learn</h3>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm box1">
                    <div class="row">
                        <div class="col-sm">
                            <img src="./images/art3.png" class="img-fluid">
                            <h3 class="card-title text-white hide">Notebook</h3>
                        </div>
                   </div>
                </div>
            </div>
            <div class="row style_left">
                <div class="col-sm box2  ">
                    <a href="#!activities">
                        <div class="row">
                            <div class="col-sm text-left">
                                <img src="./images/fuun.png" class="img-fluid">
                            </div>
                            <div class="col-sm my-auto text-left hide">
                                <h3 class="card-title text-white ">Fun Zone</h3>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm box2">
                    <div class="row">
                        <div class="col-sm">
                            <img src="./images/task2.png" class="img-fluid">
                            <h3 class="card-title text-white hide">Tasks</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>
</div>
