
<form class="form-horizontal well" action="<?php echo base_url(); ?>index.php/welcome/import" method="post" name="upload_excel" enctype="multipart/form-data">
<input type="file" name="file" id="file" class="input-large">
<button type="submit" id="submit" name="Import" class="btn btn-primary button-loading">Upload</button>
</form>