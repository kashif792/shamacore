<?php
class Principal_controller extends MY_Controller

{

}

?>